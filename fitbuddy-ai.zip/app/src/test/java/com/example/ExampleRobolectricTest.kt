package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.EquipmentType
import com.example.data.model.ExperienceLevel
import com.example.data.model.FitnessGoal
import com.example.data.model.UserProfile
import com.example.data.repository.WorkoutPlannerEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FitBuddy AI", appName)
  }

  @Test
  fun `workout planner generates correct day count and exercises`() {
    val profile = UserProfile(
      name = "Alex",
      goal = FitnessGoal.MUSCLE_GAIN,
      experience = ExperienceLevel.BEGINNER,
      equipment = EquipmentType.DUMBBELLS,
      daysPerWeek = 4,
      preferredDurationMinutes = 45
    )

    val plan = WorkoutPlannerEngine.generatePlan(profile)
    assertEquals(4, plan.days.size)
    assertTrue(plan.title.contains("Muscle Gain"))
    assertTrue(plan.days.first().exercises.isNotEmpty())
  }

  @Test
  fun `monetization repository switches tiers and tracks rewarded unlocks`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = com.example.data.repository.MonetizationRepository(context)

    // Initial state
    assertEquals(com.example.data.model.MembershipTier.FREE_SPONSORED, repo.state.value.tier)
    assertTrue(repo.state.value.adsEnabled)

    // Upgrade to Pro
    repo.setMembershipTier(com.example.data.model.MembershipTier.PRO_MEMBER)
    assertEquals(com.example.data.model.MembershipTier.PRO_MEMBER, repo.state.value.tier)
    org.junit.Assert.assertFalse(repo.state.value.adsEnabled)

    // Claim rewarded boost
    val initialViews = repo.state.value.totalPromotionsViewed
    repo.recordPromotionRewardClaimed()
    assertEquals(initialViews + 1, repo.state.value.totalPromotionsViewed)
    assertTrue(repo.state.value.unlockedAdvancedSplits)
  }

  @Test
  fun `motivation repository returns intense limit breaking quotes`() {
    val quote = com.example.data.repository.MotivationRepository.getTodayQuote()
    val beastQuote = com.example.data.repository.MotivationRepository.getRandomBeastQuote()
    assertTrue(quote.isNotBlank())
    assertTrue(beastQuote.isNotBlank())
    assertTrue(com.example.data.repository.MotivationRepository.dailyQuotes.size >= 10)
  }

  @Test
  fun `alarm alert manager executes vibration and sets device alarm intent`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    // Test vibration trigger without crashing
    com.example.util.AlarmAlertManager.triggerAlarmVibration(context)
    com.example.util.AlarmAlertManager.playCountdownPip(context)

    // Test alarm intent dispatch
    val result = com.example.util.AlarmAlertManager.setSystemAlarm(context, 6, 30, "Morning Lift")
    assertTrue(result)
  }
}
