package com.example.data.repository

import com.example.data.db.WorkoutRecordEntity
import com.example.data.model.AchievementBadge

object MotivationRepository {

    val dailyQuotes = listOf(
        "\"Don't stop when you're tired. Stop when you're done. When your mind screams surrender, that is the exact second your real workout begins.\"",
        "\"The only limit to your human potential is the voice inside your head lying to you that you've had enough. Silence it with heavy iron.\"",
        "\"Pain is temporary. Quitting is forever. Go into that dark place and unleash the savage within.\"",
        "\"When your body screams you're at 100% exhaustion, science proves you've only tapped 40% of what you can endure. Dig deeper.\"",
        "\"Nobody is coming to save you. Nobody is lifting this weight for you. It's you versus you. Destroy your yesterday.\"",
        "\"Suffer the pain of discipline today, or suffer the rotting agony of regret forever. Choose your pain.\"",
        "\"Discipline is doing what must be done with relentless ferocity, especially when every fiber of your body wants to quit.\"",
        "\"The iron never lies to you. 200 pounds will always be 200 pounds. It will not negotiate. Step up and conquer it.\"",
        "\"You don't grow when things are comfortable. You grow when you're gasping for air, shaking under the bar, and refusing to drop it.\"",
        "\"Turn your inner demons into pure fuel. Every repetition is a strike against the voice telling you to be average.\"",
        "\"Do not pray for an easy session. Train yourself to become an unstoppable force that shatters every obstacle.\"",
        "\"Greatness isn't a gift. It's an obsession forged in cold iron, callused hands, sweat, and zero fucking excuses.\"",
        "\"Break your limits before your limits break you. Attack the rack with violent focus.\"",
        "\"When you feel like dying, remember why you started and give one more brutal rep.\"",
        "\"Leave everything on the gym floor. Walk out empty, proud, and completely transformed.\""
    )

    fun getTodayQuote(): String {
        val dayOfYear = java.time.LocalDate.now().dayOfYear
        return dailyQuotes[dayOfYear % dailyQuotes.size]
    }

    fun getRandomBeastQuote(): String {
        return dailyQuotes.random()
    }

    fun computeBadges(
        workouts: List<WorkoutRecordEntity>,
        streak: Int,
        hasLoggedWeight: Boolean
    ): List<AchievementBadge> {
        val totalWorkouts = workouts.size
        val hasLiftOver50 = workouts.any { it.totalVolumeKg >= 500.0 }

        return listOf(
            AchievementBadge(
                id = "first_sweat",
                title = "First Sweat",
                description = "Complete your first workout session.",
                iconName = "fitness_center",
                isUnlocked = totalWorkouts >= 1
            ),
            AchievementBadge(
                id = "hat_trick",
                title = "Hat-Trick",
                description = "Maintain a 3-day active streak.",
                iconName = "local_fire_department",
                isUnlocked = streak >= 3
            ),
            AchievementBadge(
                id = "iron_will",
                title = "Iron Will",
                description = "Maintain a 7-day workout streak.",
                iconName = "military_tech",
                isUnlocked = streak >= 7
            ),
            AchievementBadge(
                id = "consistency_champ",
                title = "Consistency Champ",
                description = "Complete 5 total workouts in FitBuddy AI.",
                iconName = "emoji_events",
                isUnlocked = totalWorkouts >= 5
            ),
            AchievementBadge(
                id = "power_lifter",
                title = "Volume Crusher",
                description = "Accumulate over 500 kg total volume in a session.",
                iconName = "bolt",
                isUnlocked = hasLiftOver50
            ),
            AchievementBadge(
                id = "body_tracker",
                title = "Track & Optimize",
                description = "Record your body weight to monitor composition.",
                iconName = "monitor_weight",
                isUnlocked = hasLoggedWeight
            )
        )
    }
}
