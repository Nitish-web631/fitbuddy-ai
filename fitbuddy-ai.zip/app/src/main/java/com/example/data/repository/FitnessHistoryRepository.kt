package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.db.BodyWeightEntity
import com.example.data.db.ExerciseRecordEntity
import com.example.data.db.WorkoutRecordEntity
import com.example.data.model.ActiveWorkoutSession
import com.example.data.model.PersonalRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FitnessHistoryRepository(private val database: AppDatabase) {

    val allWorkouts: Flow<List<WorkoutRecordEntity>> = database.workoutDao().getAllWorkouts()
    val totalWorkoutsCount: Flow<Int> = database.workoutDao().getTotalWorkoutsCount()
    val allWeights: Flow<List<BodyWeightEntity>> = database.weightDao().getAllWeights()
    val latestWeight: Flow<BodyWeightEntity?> = database.weightDao().getLatestWeight()

    suspend fun saveCompletedWorkout(
        session: ActiveWorkoutSession,
        notes: String = ""
    ): Long {
        val now = System.currentTimeMillis()
        var totalCompletedExercises = 0
        var totalVolume = 0.0
        val exerciseRecords = mutableListOf<ExerciseRecordEntity>()

        session.exercises.forEach { exState ->
            val completedSets = exState.sets.filter { it.isCompleted }
            if (completedSets.isNotEmpty()) {
                totalCompletedExercises++
            }
            completedSets.forEach { setItem ->
                totalVolume += (setItem.weightKg * setItem.reps)
                exerciseRecords.add(
                    ExerciseRecordEntity(
                        workoutRecordId = 0L, // will update below
                        exerciseName = exState.name,
                        setIndex = setItem.setNumber,
                        weightKg = setItem.weightKg,
                        reps = setItem.reps,
                        dateEpochMillis = now
                    )
                )
            }
        }

        val workoutEntity = WorkoutRecordEntity(
            dateEpochMillis = now,
            workoutTitle = "${session.planTitle} • ${session.dayTitle}",
            dayNumber = session.dayNumber,
            durationSeconds = session.elapsedSeconds,
            completedExercisesCount = totalCompletedExercises,
            totalExercisesCount = session.exercises.size,
            totalVolumeKg = totalVolume,
            notes = notes
        )

        val workoutId = database.workoutDao().insertWorkoutRecord(workoutEntity)
        val linkedRecords = exerciseRecords.map { it.copy(workoutRecordId = workoutId) }
        database.workoutDao().insertExerciseRecords(linkedRecords)

        return workoutId
    }

    suspend fun logBodyWeight(weightKg: Double, note: String = ""): Long {
        return database.weightDao().insertWeight(
            BodyWeightEntity(
                dateEpochMillis = System.currentTimeMillis(),
                weightKg = weightKg,
                note = note
            )
        )
    }

    fun getPersonalRecords(): Flow<List<PersonalRecord>> {
        val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        return database.workoutDao().getAllExerciseRecords().map { allSets ->
            allSets.groupBy { it.exerciseName }.map { (exerciseName, sets) ->
                val bestByWeight = sets.maxByOrNull { it.weightKg }
                val bestByReps = sets.maxByOrNull { it.reps }
                val dateStr = bestByWeight?.dateEpochMillis?.let { dateFormat.format(Date(it)) } ?: "Recent"
                PersonalRecord(
                    exerciseName = exerciseName,
                    maxWeightKg = bestByWeight?.weightKg ?: 0.0,
                    maxReps = bestByReps?.reps ?: 0,
                    achievedDate = dateStr
                )
            }.sortedByDescending { it.maxWeightKg }
        }
    }

    suspend fun getLastExercisePerformance(exerciseName: String): Pair<Double, Int>? {
        val record = database.workoutDao().getPersonalBestForExercise(exerciseName)
        return record?.let { Pair(it.weightKg, it.reps) }
    }

    suspend fun clearAllHistory() {
        database.workoutDao().clearAllWorkouts()
        database.workoutDao().clearAllExerciseRecords()
        database.weightDao().clearAllWeights()
    }
}
