package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_records")
data class WorkoutRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateEpochMillis: Long,
    val workoutTitle: String,
    val dayNumber: Int,
    val durationSeconds: Int,
    val completedExercisesCount: Int,
    val totalExercisesCount: Int,
    val totalVolumeKg: Double,
    val notes: String
)

@Entity(tableName = "exercise_records")
data class ExerciseRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val workoutRecordId: Long,
    val exerciseName: String,
    val setIndex: Int,
    val weightKg: Double,
    val reps: Int,
    val dateEpochMillis: Long
)

@Entity(tableName = "body_weight_records")
data class BodyWeightEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateEpochMillis: Long,
    val weightKg: Double,
    val note: String
)
