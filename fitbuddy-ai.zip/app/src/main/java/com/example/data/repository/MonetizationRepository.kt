package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.MembershipTier
import com.example.data.model.MonetizationState
import com.example.data.model.SponsoredOffer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MonetizationRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("fitbuddy_monetization_prefs", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<MonetizationState> = _state.asStateFlow()

    val availableOffers = listOf(
        SponsoredOffer(
            id = "optimum_hydration",
            sponsorName = "HydraCore Electrolytes",
            headline = "Fuel Your Heavy Sets",
            description = "Zero-sugar rapid hydration formula with magnesium & potassium for cramp prevention.",
            callToAction = "Claim 20% Off",
            category = "Nutrition & Hydration",
            rewardPerk = "Unlocks Day 6 Hypertrophy Split for 24h"
        ),
        SponsoredOffer(
            id = "apex_straps",
            sponsorName = "IronGrip Lifting Gear",
            headline = "Break Your Deadlift PR",
            description = "Heavy-duty neoprene wrist straps & lever belts trusted by powerlifters.",
            callToAction = "Explore Gear",
            category = "Fitness Equipment",
            rewardPerk = "Unlocks Advanced Personal Record Analytics"
        ),
        SponsoredOffer(
            id = "pulse_recovery",
            sponsorName = "HyperPulse Massage Gun",
            headline = "Accelerate Muscle Recovery",
            description = "Quiet brushless motor percussive therapy to flush lactic acid in under 5 minutes.",
            callToAction = "View Recovery Guide",
            category = "Recovery & Mobility",
            rewardPerk = "Unlocks Elite Cool-Down Mobility Protocols"
        )
    )

    private fun loadState(): MonetizationState {
        val isPro = prefs.getBoolean("is_pro_member", false)
        val adsEnabled = prefs.getBoolean("ads_enabled", true)
        val unlockedSplits = prefs.getBoolean("unlocked_advanced_splits", false)
        val viewedCount = prefs.getInt("promotions_viewed_count", 0)

        return MonetizationState(
            tier = if (isPro) MembershipTier.PRO_MEMBER else MembershipTier.FREE_SPONSORED,
            adsEnabled = adsEnabled && !isPro,
            unlockedAdvancedSplits = unlockedSplits || isPro,
            totalPromotionsViewed = viewedCount
        )
    }

    fun setMembershipTier(tier: MembershipTier) {
        val isPro = (tier == MembershipTier.PRO_MEMBER)
        prefs.edit().putBoolean("is_pro_member", isPro).apply()
        _state.value = _state.value.copy(
            tier = tier,
            adsEnabled = if (isPro) false else _state.value.adsEnabled,
            unlockedAdvancedSplits = isPro || _state.value.unlockedAdvancedSplits
        )
    }

    fun setAdsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("ads_enabled", enabled).apply()
        _state.value = _state.value.copy(adsEnabled = enabled && _state.value.tier != MembershipTier.PRO_MEMBER)
    }

    fun recordPromotionRewardClaimed() {
        val newCount = _state.value.totalPromotionsViewed + 1
        prefs.edit()
            .putInt("promotions_viewed_count", newCount)
            .putBoolean("unlocked_advanced_splits", true)
            .apply()

        _state.value = _state.value.copy(
            totalPromotionsViewed = newCount,
            unlockedAdvancedSplits = true
        )
    }

    fun getRandomOffer(): SponsoredOffer {
        return availableOffers.random()
    }
}
