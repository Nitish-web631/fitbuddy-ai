package com.example.data.model

enum class MembershipTier(val displayName: String, val badge: String) {
    FREE_SPONSORED("Free (Ad-Supported)", "Free"),
    PRO_MEMBER("FitBuddy Pro (Ad-Free)", "PRO")
}

data class SponsoredOffer(
    val id: String,
    val sponsorName: String,
    val headline: String,
    val description: String,
    val callToAction: String,
    val category: String,
    val rewardPerk: String
)

data class MonetizationState(
    val tier: MembershipTier = MembershipTier.FREE_SPONSORED,
    val adsEnabled: Boolean = true,
    val unlockedAdvancedSplits: Boolean = false,
    val totalPromotionsViewed: Int = 0
)
