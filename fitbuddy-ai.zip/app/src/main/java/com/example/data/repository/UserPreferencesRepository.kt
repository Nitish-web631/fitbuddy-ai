package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.EquipmentType
import com.example.data.model.ExperienceLevel
import com.example.data.model.FitnessGoal
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

class UserPreferencesRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("fitbuddy_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private fun loadProfile(): UserProfile {
        val name = prefs.getString("user_name", "Athlete") ?: "Athlete"
        val ageRange = prefs.getString("age_range", "26-35") ?: "26-35"
        val goalStr = prefs.getString("fitness_goal", FitnessGoal.MUSCLE_GAIN.name)
        val goal = try {
            FitnessGoal.valueOf(goalStr ?: FitnessGoal.MUSCLE_GAIN.name)
        } catch (_: Exception) {
            FitnessGoal.MUSCLE_GAIN
        }

        val expStr = prefs.getString("experience_level", ExperienceLevel.BEGINNER.name)
        val exp = try {
            ExperienceLevel.valueOf(expStr ?: ExperienceLevel.BEGINNER.name)
        } catch (_: Exception) {
            ExperienceLevel.BEGINNER
        }

        val equipStr = prefs.getString("equipment_type", EquipmentType.DUMBBELLS.name)
        val equip = try {
            EquipmentType.valueOf(equipStr ?: EquipmentType.DUMBBELLS.name)
        } catch (_: Exception) {
            EquipmentType.DUMBBELLS
        }

        val days = prefs.getInt("days_per_week", 3)
        val duration = prefs.getInt("duration_minutes", 45)
        val isOnboarded = prefs.getBoolean("is_onboarded", false)
        val streak = prefs.getInt("current_streak", 0)
        val lastEpochDay = prefs.getLong("last_workout_epoch_day", 0L)
        val reminderEnabled = prefs.getBoolean("reminders_enabled", true)
        val reminderTime = prefs.getString("reminder_time", "08:00 AM") ?: "08:00 AM"

        return UserProfile(
            name = name,
            ageRange = ageRange,
            goal = goal,
            experience = exp,
            equipment = equip,
            daysPerWeek = days,
            preferredDurationMinutes = duration,
            isOnboarded = isOnboarded,
            currentStreak = streak,
            lastWorkoutEpochDay = lastEpochDay,
            remindersEnabled = reminderEnabled,
            reminderTime = reminderTime
        )
    }

    fun saveProfile(profile: UserProfile) {
        prefs.edit()
            .putString("user_name", profile.name)
            .putString("age_range", profile.ageRange)
            .putString("fitness_goal", profile.goal.name)
            .putString("experience_level", profile.experience.name)
            .putString("equipment_type", profile.equipment.name)
            .putInt("days_per_week", profile.daysPerWeek)
            .putInt("duration_minutes", profile.preferredDurationMinutes)
            .putBoolean("is_onboarded", profile.isOnboarded)
            .putInt("current_streak", profile.currentStreak)
            .putLong("last_workout_epoch_day", profile.lastWorkoutEpochDay)
            .putBoolean("reminders_enabled", profile.remindersEnabled)
            .putString("reminder_time", profile.reminderTime)
            .apply()
        _userProfile.value = profile
    }

    fun recordWorkoutCompletion() {
        val todayEpochDay = LocalDate.now().toEpochDay()
        val currentProfile = _userProfile.value
        val lastDay = currentProfile.lastWorkoutEpochDay

        val newStreak = when {
            lastDay == todayEpochDay -> currentProfile.currentStreak // Already logged today
            lastDay == todayEpochDay - 1 -> currentProfile.currentStreak + 1 // Consecutive day
            lastDay == 0L -> 1 // First ever workout
            else -> 1 // Streak broken or reset
        }

        val updated = currentProfile.copy(
            currentStreak = newStreak,
            lastWorkoutEpochDay = todayEpochDay
        )
        saveProfile(updated)
    }

    fun saveActiveDraft(draftJson: String?) {
        prefs.edit().putString("active_session_draft", draftJson).apply()
    }

    fun getActiveDraft(): String? {
        return prefs.getString("active_session_draft", null)
    }

    fun resetAllData() {
        prefs.edit().clear().apply()
        _userProfile.value = UserProfile()
    }
}
