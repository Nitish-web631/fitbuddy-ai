package com.example.data.repository

import com.example.data.model.EquipmentType
import com.example.data.model.Exercise
import com.example.data.model.ExperienceLevel
import com.example.data.model.MuscleCategory

object ExerciseRepository {

    val allExercises: List<Exercise> = listOf(
        // CHEST
        Exercise(
            id = "chest_barbell_bench",
            name = "Barbell Bench Press",
            category = MuscleCategory.CHEST,
            equipment = EquipmentType.FULL_GYM,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Lie flat on the bench with your eyes under the bar and feet planted firmly on the floor.",
                "Grip the bar slightly wider than shoulder-width, arch slightly, and unrack with straight arms.",
                "Lower the bar under control until it lightly touches your mid-chest.",
                "Press the bar up explosively along a slight diagonal path back over your shoulders."
            ),
            primaryMuscles = listOf("Pectoralis Major"),
            secondaryMuscles = listOf("Triceps Brachii", "Anterior Deltoids"),
            formTips = listOf("Keep shoulder blades retracted and pinched into the bench", "Avoid flaring elbows to 90 degrees; tuck them to ~45-60 degrees"),
            alternative = "Push-ups or Dumbbell Bench Press"
        ),
        Exercise(
            id = "chest_db_press",
            name = "Dumbbell Chest Press",
            category = MuscleCategory.CHEST,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Sit on a flat bench with dumbbells resting vertically on your knees.",
                "Lie back smoothly while kicking weights up to chest level.",
                "Press dumbbells up until arms are extended but not locked out.",
                "Lower with control until elbows are slightly below the bench plane."
            ),
            primaryMuscles = listOf("Pectoralis Major"),
            secondaryMuscles = listOf("Triceps", "Front Deltoids"),
            formTips = listOf("Rotate dumbbells slightly into a gentle V-grip for joint comfort", "Maintain a neutral wrist position"),
            alternative = "Floor Dumbbell Press or Push-ups"
        ),
        Exercise(
            id = "chest_pushups",
            name = "Standard Push-Ups",
            category = MuscleCategory.CHEST,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Place hands slightly wider than shoulder-width on the floor in a solid high plank.",
                "Brace your core, glutes, and maintain a straight line from head to heels.",
                "Lower your chest until 2 inches above the ground while keeping elbows at 45 degrees.",
                "Push the floor away to return to top plank position."
            ),
            primaryMuscles = listOf("Pectoralis Major"),
            secondaryMuscles = listOf("Core", "Triceps", "Anterior Deltoids"),
            formTips = listOf("Do not let your lower back sag", "For easier variation, place hands on elevated surface or knees"),
            alternative = "Incline Wall Push-ups or Knee Push-ups"
        ),
        Exercise(
            id = "chest_band_fly",
            name = "Resistance Band Chest Fly",
            category = MuscleCategory.CHEST,
            equipment = EquipmentType.RESISTANCE_BANDS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Anchor a resistance band behind you at chest height or loop behind your upper back.",
                "Hold handles with elbows slightly bent and arms extended out to the sides.",
                "Bring your hands together in front of your chest in a hugging motion, squeezing pecs.",
                "Slowly return to start with controlled eccentric resistance."
            ),
            primaryMuscles = listOf("Pectoralis Major (Sternal Head)"),
            secondaryMuscles = listOf("Anterior Deltoids", "Biceps (isometric)"),
            formTips = listOf("Focus on the peak contraction at the front", "Maintain constant slight elbow bend"),
            alternative = "Dumbbell Floor Fly"
        ),

        // BACK
        Exercise(
            id = "back_lat_pulldown",
            name = "Lat Pulldown",
            category = MuscleCategory.BACK,
            equipment = EquipmentType.FULL_GYM,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Sit at the machine with thighs firmly secured beneath the pads.",
                "Grip the bar slightly wider than shoulder-width with palms facing away.",
                "Depress shoulders and pull the bar down toward your upper collarbone while leaning back slightly (~10°).",
                "Control the bar back up until your lats are fully stretched."
            ),
            primaryMuscles = listOf("Latissimus Dorsi"),
            secondaryMuscles = listOf("Biceps", "Rhomboids", "Rear Deltoids"),
            formTips = listOf("Initiate the pull by driving elbows straight down and back", "Avoid swinging your torso excessively"),
            alternative = "Resistance Band Lat Pulldown or Inverted Rows"
        ),
        Exercise(
            id = "back_db_row",
            name = "One-Arm Dumbbell Row",
            category = MuscleCategory.BACK,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Place one knee and matching hand on a flat bench, keeping back parallel to the floor.",
                "Pick up dumbbell with other hand, letting arm hang fully extended.",
                "Pull dumbbell up towards your hip crease, driving your elbow upward.",
                "Pause for a beat at peak contraction, then lower slowly."
            ),
            primaryMuscles = listOf("Latissimus Dorsi", "Rhomboids"),
            secondaryMuscles = listOf("Biceps", "Posterior Deltoids"),
            formTips = listOf("Keep your torso still and resist twisting your hips", "Think of pulling from the elbow, not the hand"),
            alternative = "Resistance Band Single Arm Row"
        ),
        Exercise(
            id = "back_pullup",
            name = "Pull-Ups / Chin-Ups",
            category = MuscleCategory.BACK,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.ADVANCED,
            instructions = listOf(
                "Hang from a sturdy pull-up bar with hands just outside shoulder-width.",
                "Engage shoulders down away from ears into an active hang.",
                "Pull chest toward the bar by driving elbows down into your ribs.",
                "Lower under control to a full dead hang without swinging."
            ),
            primaryMuscles = listOf("Latissimus Dorsi", "Upper Back"),
            secondaryMuscles = listOf("Biceps", "Forearms", "Core"),
            formTips = listOf("Cross ankles and squeeze glutes to eliminate swing", "Use a resistance band loop for assistance if needed"),
            alternative = "Inverted Bodyweight Rows or Band Lat Pulldown"
        ),
        Exercise(
            id = "back_band_row",
            name = "Seated Band Row",
            category = MuscleCategory.BACK,
            equipment = EquipmentType.RESISTANCE_BANDS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Sit on the floor with legs extended, looping band around feet balls.",
                "Sit tall with chest high and spine neutral, holding band handles.",
                "Pull bands back towards your lower ribcage, squeezing shoulder blades together.",
                "Slowly extend arms forward with resistance."
            ),
            primaryMuscles = listOf("Mid Back", "Rhomboids", "Lats"),
            secondaryMuscles = listOf("Biceps", "Rear Delts"),
            formTips = listOf("Do not round your lower back; sit right on your sit bones", "Hold the squeeze for 1 second"),
            alternative = "Dumbbell Bent Over Row"
        ),

        // SHOULDERS
        Exercise(
            id = "shoulder_db_overhead",
            name = "Dumbbell Shoulder Press",
            category = MuscleCategory.SHOULDERS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Sit upright with back supported, holding dumbbells at ear level with palms forward or neutral.",
                "Press dumbbells straight overhead until arms are fully extended.",
                "Carefully lower the weights back to collarbone level."
            ),
            primaryMuscles = listOf("Anterior Deltoids", "Lateral Deltoids"),
            secondaryMuscles = listOf("Triceps", "Upper Traps"),
            formTips = listOf("Do not arch your lower spine; keep ribs glued down", "Press up in a smooth arc"),
            alternative = "Pike Push-ups or Band Overhead Press"
        ),
        Exercise(
            id = "shoulder_lateral_raise",
            name = "Dumbbell Lateral Raise",
            category = MuscleCategory.SHOULDERS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Stand tall with feet hip-width, holding dumbbells at your sides.",
                "With a slight forward torso lean and soft elbows, raise arms out to the sides.",
                "Lift until arms reach parallel with the ground at shoulder height.",
                "Lower weights slowly over 2-3 seconds."
            ),
            primaryMuscles = listOf("Lateral (Side) Deltoids"),
            secondaryMuscles = listOf("Trapezius"),
            formTips = listOf("Lead with your elbows, not hands", "Use light weights to isolate the side delt rather than using momentum"),
            alternative = "Resistance Band Lateral Raise"
        ),
        Exercise(
            id = "shoulder_pike_pushup",
            name = "Pike Push-Ups",
            category = MuscleCategory.SHOULDERS,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Start in a downward dog yoga posture with hips high in an inverted V-shape.",
                "Look down at your toes with hands shoulder-width apart.",
                "Bend elbows to lower crown of your head diagonally forward towards the floor.",
                "Push through palms to return hips high."
            ),
            primaryMuscles = listOf("Anterior & Lateral Deltoids"),
            secondaryMuscles = listOf("Triceps", "Upper Chest", "Serratus Anterior"),
            formTips = listOf("Move forward into a tripod shape at the bottom, not straight down", "Elevate feet on bench for increased resistance"),
            alternative = "Elevated Hand Push-ups or Wall Handstand Holds"
        ),
        Exercise(
            id = "shoulder_face_pull",
            name = "Cable or Band Face Pull",
            category = MuscleCategory.SHOULDERS,
            equipment = EquipmentType.FULL_GYM,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Set pulley or anchor at eye level with a rope attachment or loop band.",
                "Step back into a split stance and grip rope with thumbs pointing backward.",
                "Pull toward bridge of nose while externally rotating shoulders.",
                "Pause for 1 second with hands higher than elbows."
            ),
            primaryMuscles = listOf("Rear Deltoids", "Rotator Cuff"),
            secondaryMuscles = listOf("Rhomboids", "Mid Traps"),
            formTips = listOf("Crucial exercise for shoulder longevity and postural health", "Avoid pulling solely with your biceps"),
            alternative = "Prone Y-T-W Raises on floor"
        ),

        // LEGS
        Exercise(
            id = "legs_goblet_squat",
            name = "Goblet Squat",
            category = MuscleCategory.LEGS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Hold a dumbbell vertically against your upper chest with both hands under the top plate.",
                "Stand with feet shoulder-width apart, toes turned slightly outwards.",
                "Hinge at hips and bend knees, driving knees outward over second toe.",
                "Squat until hips are at least parallel with knees, then push through mid-foot to stand."
            ),
            primaryMuscles = listOf("Quadriceps", "Glutes"),
            secondaryMuscles = listOf("Hamstrings", "Calves", "Core"),
            formTips = listOf("Keep chest proud and elbows tucked inside knees at bottom", "Breathe in on way down, exhale as you power up"),
            alternative = "Bodyweight Air Squats"
        ),
        Exercise(
            id = "legs_barbell_squat",
            name = "Barbell Back Squat",
            category = MuscleCategory.LEGS,
            equipment = EquipmentType.FULL_GYM,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Step under bar placed on upper traps (high bar) or rear delts (low bar).",
                "Unrack with a solid breath, take 2 steps back into squat stance.",
                "Descend with controlled cadence until hip crease is below knee level.",
                "Drive through the floor while keeping chest up to lock out hips."
            ),
            primaryMuscles = listOf("Quadriceps", "Gluteus Maximus"),
            secondaryMuscles = listOf("Hamstrings", "Erector Spinae", "Adductors"),
            formTips = listOf("Brace abdomen with Valsalva technique before descent", "Never let knees cave inward"),
            alternative = "Goblet Squat or Leg Press"
        ),
        Exercise(
            id = "legs_lunges",
            name = "Walking / Reverse Lunges",
            category = MuscleCategory.LEGS,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Stand upright, hands on hips or holding dumbbells.",
                "Step backward into a deep lunge until back knee hovers an inch above ground.",
                "Both front and back knees should form approximately 90-degree angles.",
                "Push off front heel to return to standing position."
            ),
            primaryMuscles = listOf("Quadriceps", "Glutes"),
            secondaryMuscles = listOf("Hamstrings", "Calves", "Hip Stabilizers"),
            formTips = listOf("Reverse lunges are gentler on patellar knee tendons than forward lunges", "Keep torso upright"),
            alternative = "Stationary Split Squat with wall support"
        ),
        Exercise(
            id = "legs_romanian_deadlift",
            name = "Dumbbell Romanian Deadlift (RDL)",
            category = MuscleCategory.LEGS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Hold dumbbells in front of thighs with feet hip-width apart and knees unlocked.",
                "Push hips directly backwards as if trying to touch the wall behind you.",
                "Lower weights along shins until you feel a deep stretch in hamstrings.",
                "Squeeze glutes and drive hips forward to return to standing."
            ),
            primaryMuscles = listOf("Hamstrings", "Gluteus Maximus"),
            secondaryMuscles = listOf("Lower Back", "Forearms"),
            formTips = listOf("Keep back flat as a tabletop; do not bend spine", "Do not squat the weight down; this is a pure hip hinge"),
            alternative = "Glute Bridges or Resistance Band Good Mornings"
        ),
        Exercise(
            id = "legs_glute_bridge",
            name = "Glute Bridge",
            category = MuscleCategory.LEGS,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Lie on your back with knees bent and feet flat on floor, hip-width apart.",
                "Arms flat by your sides for stability.",
                "Drive through heels to lift hips until thighs and torso align.",
                "Squeeze glutes at top for 2 seconds, then lower with control."
            ),
            primaryMuscles = listOf("Gluteus Maximus"),
            secondaryMuscles = listOf("Hamstrings", "Core"),
            formTips = listOf("Avoid overarching lumbar lower back at the top", "Place dumbbell across hips for extra resistance"),
            alternative = "Single-Leg Glute Bridge"
        ),

        // ARMS
        Exercise(
            id = "arms_bicep_curl",
            name = "Dumbbell Bicep Curl",
            category = MuscleCategory.ARMS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Stand with dumbbells hanging at arm's length, palms facing inward or forward.",
                "Keeping upper arms pinned close to your sides, curl weights toward shoulders.",
                "Squeeze biceps firmly at the top without rocking torso.",
                "Lower weights slowly through full range of motion."
            ),
            primaryMuscles = listOf("Biceps Brachii"),
            secondaryMuscles = listOf("Brachialis", "Forearm Flexors"),
            formTips = listOf("Do not swing your body; stay locked like a statue", "Control the downward negative phase"),
            alternative = "Resistance Band Bicep Curls"
        ),
        Exercise(
            id = "arms_tricep_dips",
            name = "Bench / Chair Tricep Dips",
            category = MuscleCategory.ARMS,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Place palms on the edge of a sturdy bench or chair, fingers pointing forward.",
                "Extend legs forward with knees bent (easier) or straight (harder).",
                "Lower body by bending elbows straight back until arms reach ~90 degrees.",
                "Press forcefully through palms to lock out triceps."
            ),
            primaryMuscles = listOf("Triceps Brachii"),
            secondaryMuscles = listOf("Anterior Deltoids", "Chest"),
            formTips = listOf("Keep back close to the bench to safeguard shoulders", "Avoid dipping below 90 degrees if shoulders feel tight"),
            alternative = "Overhead Dumbbell Tricep Extension"
        ),
        Exercise(
            id = "arms_overhead_tricep",
            name = "Overhead Dumbbell Tricep Extension",
            category = MuscleCategory.ARMS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Hold one dumbbell with both hands cupping the top inner weight plate overhead.",
                "Keep upper arms vertical and close to ears.",
                "Lower the dumbbell behind your head by bending only at elbows.",
                "Extend elbows back to top position with a crisp tricep squeeze."
            ),
            primaryMuscles = listOf("Triceps (Long Head)"),
            secondaryMuscles = listOf("Forearms"),
            formTips = listOf("Keep core tight so ribs do not flare", "Elbows should point forward, not outward"),
            alternative = "Diamond Push-ups or Band Tricep Pressdown"
        ),
        Exercise(
            id = "arms_hammer_curl",
            name = "Dumbbell Hammer Curls",
            category = MuscleCategory.ARMS,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Hold dumbbells with neutral grip (palms facing each other) throughout entire movement.",
                "Curl both weights upward towards shoulders while maintaining neutral wrist position.",
                "Squeeze brachialis and forearms at peak, then lower slowly."
            ),
            primaryMuscles = listOf("Brachialis", "Brachioradialis (Forearms)"),
            secondaryMuscles = listOf("Biceps Brachii"),
            formTips = listOf("Builds arm thickness and improves grip strength", "Keep elbows stationary"),
            alternative = "Band Neutral Curls"
        ),

        // CORE
        Exercise(
            id = "core_plank",
            name = "Forearm Plank",
            category = MuscleCategory.CORE,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Rest on forearms with elbows directly under shoulders, toes tucked on the floor.",
                "Create a straight line from crown of head through tailbone to ankles.",
                "Actively push floor away, pull belly button to spine, and squeeze glutes hard.",
                "Breathe steadily without letting hips hike or dip."
            ),
            primaryMuscles = listOf("Transverse Abdominis", "Rectus Abdominis"),
            secondaryMuscles = listOf("Obliques", "Glutes", "Shoulder Stabilizers"),
            formTips = listOf("Quality over duration; a tight 30-second plank beats a saggy 2-minute plank", "If tired, drop to knees for active recovery"),
            alternative = "Knee Plank or Bird Dog"
        ),
        Exercise(
            id = "core_deadbug",
            name = "Dead Bug",
            category = MuscleCategory.CORE,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Lie on back with arms extended toward ceiling and legs up in 90-degree tabletop.",
                "Press lower back completely flush against the floor.",
                "Slowly extend right arm overhead and left leg forward towards floor simultaneously.",
                "Return to start and repeat with opposite limbs."
            ),
            primaryMuscles = listOf("Deep Core", "Transverse Abdominis"),
            secondaryMuscles = listOf("Hip Flexors", "Pelvic Floor"),
            formTips = listOf("If your lower back arches off the mat, do not lower your leg as far", "Breathe out as limbs extend"),
            alternative = "Bird Dog on hands and knees"
        ),
        Exercise(
            id = "core_russian_twists",
            name = "Russian Twists",
            category = MuscleCategory.CORE,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Sit with knees bent, feet hovering (or resting on floor for beginner level).",
                "Lean torso back ~45 degrees with straight spine to engage abdominals.",
                "Rotate torso slowly from side to side, touching hands to floor beside hips.",
                "Perform with control rather than rapid speed."
            ),
            primaryMuscles = listOf("Internal & External Obliques"),
            secondaryMuscles = listOf("Rectus Abdominis", "Hip Flexors"),
            formTips = listOf("Rotate from ribcage and shoulders, not just moving hands", "Hold a dumbbell or water bottle for added intensity"),
            alternative = "Side Plank or Bicycle Crunches"
        ),
        Exercise(
            id = "core_hanging_leg_raise",
            name = "Hanging Knee / Leg Raises",
            category = MuscleCategory.CORE,
            equipment = EquipmentType.FULL_GYM,
            difficulty = ExperienceLevel.ADVANCED,
            instructions = listOf(
                "Hang from a pull-up bar with an overhand grip.",
                "Without swinging, tilt pelvis upward and raise knees towards chest.",
                "Lower slowly under control without relying on momentum."
            ),
            primaryMuscles = listOf("Lower Rectus Abdominis"),
            secondaryMuscles = listOf("Hip Flexors", "Grip & Forearms"),
            formTips = listOf("Focus on curling the pelvis toward sternum, not just lifting legs", "Perform on captain's chair if bar grip is limiting"),
            alternative = "Lying Reverse Crunches"
        ),

        // FULL BODY & CONDITIONING
        Exercise(
            id = "fb_burpees",
            name = "Burpees",
            category = MuscleCategory.FULL_BODY,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Stand with feet shoulder-width apart, drop into a squat and place hands on floor.",
                "Kick or step feet back into a plank and lower chest to floor.",
                "Press back up, jump or step feet forward to hands.",
                "Explode upward in a jump with hands reaching overhead."
            ),
            primaryMuscles = listOf("Cardiovascular System", "Full Body"),
            secondaryMuscles = listOf("Chest", "Legs", "Core"),
            formTips = listOf("Step back instead of jumping to make it low-impact for joints", "Maintain steady rhythmic breathing"),
            alternative = "Step-back Sprawls without push-up or jump"
        ),
        Exercise(
            id = "fb_mountain_climbers",
            name = "Mountain Climbers",
            category = MuscleCategory.FULL_BODY,
            equipment = EquipmentType.BODYWEIGHT,
            difficulty = ExperienceLevel.BEGINNER,
            instructions = listOf(
                "Start in strong high plank position with shoulders stacked over wrists.",
                "Drive right knee towards chest without lifting hips high.",
                "Quickly return right foot and drive left knee forward in alternating cadence.",
                "Keep core braced and shoulders steady."
            ),
            primaryMuscles = listOf("Cardio", "Core"),
            secondaryMuscles = listOf("Shoulders", "Hip Flexors", "Quads"),
            formTips = listOf("Keep hips low and level with shoulders", "Can be performed at a slow deliberate tempo for pure core stability"),
            alternative = "Slow march in plank or elevated plank"
        ),
        Exercise(
            id = "fb_db_thruster",
            name = "Dumbbell Thrusters",
            category = MuscleCategory.FULL_BODY,
            equipment = EquipmentType.DUMBBELLS,
            difficulty = ExperienceLevel.INTERMEDIATE,
            instructions = listOf(
                "Hold dumbbells at shoulder height in a clean rack position.",
                "Squat down until thighs are parallel with ground.",
                "Explode upward through legs, transferring power directly into overhead press.",
                "Lower weights back to shoulders smoothly as you begin next squat repetition."
            ),
            primaryMuscles = listOf("Quadriceps", "Shoulders", "Glutes"),
            secondaryMuscles = listOf("Triceps", "Core", "Heart Rate"),
            formTips = listOf("Use leg momentum to assist overhead press", "Synchronize breathing: exhale as you press up"),
            alternative = "Bodyweight Squat to Overhead Reach"
        )
    )

    fun getExerciseById(id: String): Exercise? {
        return allExercises.find { it.id == id }
    }

    fun searchExercises(query: String, category: MuscleCategory, equipment: EquipmentType?): List<Exercise> {
        return allExercises.filter { exercise ->
            val matchesQuery = query.isBlank() ||
                exercise.name.contains(query, ignoreCase = true) ||
                exercise.primaryMuscles.any { it.contains(query, ignoreCase = true) } ||
                exercise.secondaryMuscles.any { it.contains(query, ignoreCase = true) }

            val matchesCategory = (category == MuscleCategory.ALL) || (exercise.category == category)
            val matchesEquipment = (equipment == null) || (exercise.equipment == equipment) ||
                (equipment == EquipmentType.FULL_GYM) // Full gym users can do all exercises

            matchesQuery && matchesCategory && matchesEquipment
        }
    }
}
