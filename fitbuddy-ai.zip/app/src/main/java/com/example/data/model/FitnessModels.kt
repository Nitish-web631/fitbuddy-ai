package com.example.data.model

enum class FitnessGoal(val displayName: String, val shortDesc: String, val repRange: String, val restSec: Int) {
    MUSCLE_GAIN("Muscle Gain", "Hypertrophy training for size & definition", "8-12 reps", 90),
    FAT_LOSS("Fat Loss", "High-density calorie burning & metabolic circuits", "12-15 reps", 45),
    STRENGTH("Strength & Power", "Heavy progressive overload for max strength", "4-6 reps", 120),
    GENERAL_FITNESS("General Fitness", "Balanced functional strength, stamina & mobility", "10-12 reps", 60)
}

enum class ExperienceLevel(val displayName: String, val badgeColor: Long) {
    BEGINNER("Beginner", 0xFF69F0AE),
    INTERMEDIATE("Intermediate", 0xFF40C4FF),
    ADVANCED("Advanced", 0xFFFFB300)
}

enum class EquipmentType(val displayName: String) {
    FULL_GYM("Full Gym (Barbell, Cables, Machines)"),
    DUMBBELLS("Dumbbells & Bench"),
    RESISTANCE_BANDS("Resistance Bands"),
    BODYWEIGHT("Bodyweight Only (No Equipment)")
}

enum class MuscleCategory(val displayName: String) {
    ALL("All"),
    CHEST("Chest"),
    BACK("Back"),
    SHOULDERS("Shoulders"),
    ARMS("Arms"),
    LEGS("Legs"),
    CORE("Core"),
    FULL_BODY("Full Body")
}

data class UserProfile(
    val name: String = "Athlete",
    val ageRange: String = "26-35",
    val goal: FitnessGoal = FitnessGoal.MUSCLE_GAIN,
    val experience: ExperienceLevel = ExperienceLevel.BEGINNER,
    val equipment: EquipmentType = EquipmentType.DUMBBELLS,
    val daysPerWeek: Int = 3,
    val preferredDurationMinutes: Int = 45,
    val isOnboarded: Boolean = false,
    val currentStreak: Int = 0,
    val lastWorkoutEpochDay: Long = 0L,
    val remindersEnabled: Boolean = true,
    val reminderTime: String = "08:00 AM"
)

data class Exercise(
    val id: String,
    val name: String,
    val category: MuscleCategory,
    val equipment: EquipmentType,
    val difficulty: ExperienceLevel,
    val instructions: List<String>,
    val primaryMuscles: List<String>,
    val secondaryMuscles: List<String>,
    val formTips: List<String>,
    val alternative: String
)

data class PlanExercise(
    val exerciseId: String,
    val name: String,
    val category: MuscleCategory,
    val targetSets: Int,
    val targetReps: String,
    val targetWeightKg: Double,
    val restSeconds: Int,
    val instructionsSummary: String,
    val alternative: String
)

data class WorkoutDay(
    val dayNumber: Int,
    val title: String,
    val muscleFocus: String,
    val estimatedMinutes: Int,
    val warmUp: List<String>,
    val exercises: List<PlanExercise>,
    val coolDown: List<String>
)

data class WorkoutPlan(
    val title: String,
    val splitType: String,
    val description: String,
    val aiCoachNote: String,
    val engineType: String,
    val days: List<WorkoutDay>
)

data class LoggedSet(
    val setNumber: Int,
    var weightKg: Double,
    var reps: Int,
    var isCompleted: Boolean = false
)

data class ActiveExerciseState(
    val exerciseId: String,
    val name: String,
    val category: MuscleCategory,
    val restSeconds: Int,
    val alternative: String,
    val sets: List<LoggedSet>
)

data class ActiveWorkoutSession(
    val planTitle: String,
    val dayTitle: String,
    val dayNumber: Int,
    var elapsedSeconds: Int = 0,
    var exercises: List<ActiveExerciseState> = emptyList(),
    var isFinished: Boolean = false
)

data class PersonalRecord(
    val exerciseName: String,
    val maxWeightKg: Double,
    val maxReps: Int,
    val achievedDate: String
)

data class AchievementBadge(
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val isUnlocked: Boolean,
    val unlockedAt: String? = null
)
