package com.example.data.repository

import com.example.data.model.EquipmentType
import com.example.data.model.ExperienceLevel
import com.example.data.model.FitnessGoal
import com.example.data.model.MuscleCategory
import com.example.data.model.PlanExercise
import com.example.data.model.UserProfile
import com.example.data.model.WorkoutDay
import com.example.data.model.WorkoutPlan

object WorkoutPlannerEngine {

    fun generatePlan(profile: UserProfile): WorkoutPlan {
        val repScheme = profile.goal.repRange
        val restSeconds = profile.goal.restSec
        val targetSets = when (profile.experience) {
            ExperienceLevel.BEGINNER -> 3
            ExperienceLevel.INTERMEDIATE -> 3
            ExperienceLevel.ADVANCED -> 4
        }

        val daysCount = profile.daysPerWeek.coerceIn(2, 6)
        val daysList = mutableListOf<WorkoutDay>()

        val splitName = when (daysCount) {
            2 -> "Full Body Frequency Split"
            3 -> if (profile.goal == FitnessGoal.MUSCLE_GAIN) "Push / Pull / Legs Split" else "3-Day Full Body Conditioning"
            4 -> "Upper / Lower Dynamic Split"
            5 -> "Hypertrophy Push / Pull / Legs + Athletic Split"
            else -> "Classic PPL High-Volume Split"
        }

        for (i in 1..daysCount) {
            val dayPlan = buildDay(i, daysCount, profile, targetSets, repScheme, restSeconds)
            daysList.add(dayPlan)
        }

        val coachNote = buildCoachNote(profile)
        val engineName = "FitBuddy Adaptive Sports Science Engine"

        return WorkoutPlan(
            title = "${profile.goal.displayName} • $splitName",
            splitType = splitName,
            description = "Customized for ${profile.experience.displayName} level with ${profile.equipment.displayName} over ${profile.daysPerWeek} days/week (~${profile.preferredDurationMinutes} min per session).",
            aiCoachNote = coachNote,
            engineType = engineName,
            days = daysList
        )
    }

    private fun buildDay(
        dayNumber: Int,
        totalDays: Int,
        profile: UserProfile,
        targetSets: Int,
        repScheme: String,
        restSeconds: Int
    ): WorkoutDay {
        val exercises = mutableListOf<PlanExercise>()
        val warmUp = mutableListOf<String>()
        val coolDown = mutableListOf<String>()
        val title: String
        val focus: String

        when {
            // 2 Days: Full Body A & B
            totalDays == 2 -> {
                if (dayNumber == 1) {
                    title = "Day 1: Full Body Strength A"
                    focus = "Chest, Quads, Back & Core"
                    warmUp.addAll(listOf("3 min jumping jacks or brisk walk", "Arm circles (15 forward, 15 backward)", "10 bodyweight air squats", "World's Greatest Stretch (5 per side)"))
                    exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.CHEST, MuscleCategory.LEGS, MuscleCategory.BACK, MuscleCategory.CORE), profile, targetSets, repScheme, restSeconds))
                    coolDown.addAll(listOf("Standing quad stretch (30s each)", "Doorway chest opener (30s)", "Child's Pose (45s)"))
                } else {
                    title = "Day 2: Full Body Strength B"
                    focus = "Hamstrings, Shoulders, Arms & Conditioning"
                    warmUp.addAll(listOf("3 min light jog in place", "Cat-Cow spine mobility (10 reps)", "Inchworm walks (5 reps)", "Glute bridges (10 reps)"))
                    exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.LEGS, MuscleCategory.SHOULDERS, MuscleCategory.ARMS, MuscleCategory.FULL_BODY), profile, targetSets, repScheme, restSeconds))
                    coolDown.addAll(listOf("Seated hamstring stretch (40s)", "Cross-body shoulder stretch (30s)", "Cobra abdominal stretch (30s)"))
                }
            }
            // 3 Days: Push / Pull / Legs or Full Body
            totalDays == 3 -> {
                when (dayNumber) {
                    1 -> {
                        title = "Day 1: Push Power (Chest & Shoulders)"
                        focus = "Chest, Shoulders & Triceps"
                        warmUp.addAll(listOf("2 min arm swings and thoracic rotations", "Scapular push-ups (10 reps)", "Band pull-aparts or wall slides (12 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.CHEST, MuscleCategory.SHOULDERS, MuscleCategory.ARMS), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Chest wall stretch (30s)", "Overhead triceps stretch (30s)", "Child's pose deep breathing (1 min)"))
                    }
                    2 -> {
                        title = "Day 2: Pull Power (Back & Arms)"
                        focus = "Lats, Upper Back, Biceps & Core"
                        warmUp.addAll(listOf("Cat-Cow mobility (10 reps)", "Dead bugs (10 reps)", "Band dislocates (10 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.BACK, MuscleCategory.ARMS, MuscleCategory.CORE), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Lat hang or doorway stretch (30s)", "Bicep wall stretch (30s)", "Supine spinal twist (45s)"))
                    }
                    else -> {
                        title = "Day 3: Legs & Core Foundation"
                        focus = "Quads, Hamstrings, Glutes & Abs"
                        warmUp.addAll(listOf("3 min light cardio", "Leg swings front-to-back (10 per leg)", "Bodyweight squats (12 reps)", "Ankle mobility circles"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.LEGS, MuscleCategory.LEGS, MuscleCategory.CORE, MuscleCategory.FULL_BODY), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Pigeon pose or figure four stretch (45s per leg)", "Standing calf stretch (30s)", "Butterfly groin stretch (45s)"))
                    }
                }
            }
            // 4 Days: Upper / Lower Split
            totalDays == 4 -> {
                when (dayNumber) {
                    1 -> {
                        title = "Day 1: Upper Body Strength"
                        focus = "Chest, Back & Shoulders"
                        warmUp.addAll(listOf("Arm swings (20 reps)", "Scapular retractions (10 reps)", "Light push-ups (8 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.CHEST, MuscleCategory.BACK, MuscleCategory.SHOULDERS), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Chest stretch (30s)", "Cross-body shoulder stretch (30s)", "Child's pose (1 min)"))
                    }
                    2 -> {
                        title = "Day 2: Lower Body Power"
                        focus = "Quads, Hamstrings & Glutes"
                        warmUp.addAll(listOf("Glute bridges (12 reps)", "Bodyweight lunges (8 per side)", "Lateral monster walks or hip openers"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.LEGS, MuscleCategory.LEGS, MuscleCategory.CORE), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Hamstring fold (45s)", "Quad stretch (30s)", "Deep squat hold (30s)"))
                    }
                    3 -> {
                        title = "Day 3: Upper Body Hypertrophy"
                        focus = "Back, Chest & Arms"
                        warmUp.addAll(listOf("Jumping jacks (2 min)", "Thoracic foam roll or twist (10 reps)", "Band pull-aparts"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.BACK, MuscleCategory.CHEST, MuscleCategory.ARMS), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Lat stretch (30s)", "Triceps extension stretch (30s)", "Wrist extension stretch (20s)"))
                    }
                    else -> {
                        title = "Day 4: Lower Body & Core Burn"
                        focus = "Glutes, Hamstrings, Abs & Stamina"
                        warmUp.addAll(listOf("Hip circles (10 each way)", "Mountain climbers (slow 12 reps)", "Ankle rocking (10 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.LEGS, MuscleCategory.CORE, MuscleCategory.FULL_BODY), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Lying glute stretch (45s)", "Cobra stretch (30s)", "Seated forward bend (1 min)"))
                    }
                }
            }
            // 5 or 6 Days
            else -> {
                when (dayNumber % 3) {
                    1 -> {
                        title = "Day $dayNumber: Push Focus"
                        focus = "Chest, Shoulders & Triceps"
                        warmUp.addAll(listOf("Arm circles", "Wall slides (10 reps)", "Plank shoulder taps (10 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.CHEST, MuscleCategory.SHOULDERS, MuscleCategory.ARMS), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Chest opener", "Shoulder stretch", "Tricep stretch"))
                    }
                    2 -> {
                        title = "Day $dayNumber: Pull Focus"
                        focus = "Back, Rear Delts & Biceps"
                        warmUp.addAll(listOf("Cat-cow (10 reps)", "Band pull-aparts", "Dead hang (20s)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.BACK, MuscleCategory.BACK, MuscleCategory.ARMS), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Lat stretch", "Bicep stretch", "Deep breathing"))
                    }
                    else -> {
                        title = "Day $dayNumber: Legs & Core"
                        focus = "Quads, Hamstrings, Glutes & Abs"
                        warmUp.addAll(listOf("Leg swings", "Bodyweight squats (10 reps)", "Glute bridges (12 reps)"))
                        exercises.addAll(getExercisesForCategories(listOf(MuscleCategory.LEGS, MuscleCategory.LEGS, MuscleCategory.CORE, MuscleCategory.FULL_BODY), profile, targetSets, repScheme, restSeconds))
                        coolDown.addAll(listOf("Pigeon stretch", "Quad stretch", "Hamstring stretch"))
                    }
                }
            }
        }

        return WorkoutDay(
            dayNumber = dayNumber,
            title = title,
            muscleFocus = focus,
            estimatedMinutes = profile.preferredDurationMinutes,
            warmUp = warmUp,
            exercises = exercises,
            coolDown = coolDown
        )
    }

    private fun getExercisesForCategories(
        categories: List<MuscleCategory>,
        profile: UserProfile,
        targetSets: Int,
        repScheme: String,
        restSeconds: Int
    ): List<PlanExercise> {
        val results = mutableListOf<PlanExercise>()
        val usedIds = mutableSetOf<String>()

        for (category in categories) {
            val candidates = ExerciseRepository.allExercises.filter { exercise ->
                val categoryMatch = (exercise.category == category)
                val equipmentMatch = when (profile.equipment) {
                    EquipmentType.FULL_GYM -> true
                    EquipmentType.DUMBBELLS -> (exercise.equipment == EquipmentType.DUMBBELLS || exercise.equipment == EquipmentType.BODYWEIGHT)
                    EquipmentType.RESISTANCE_BANDS -> (exercise.equipment == EquipmentType.RESISTANCE_BANDS || exercise.equipment == EquipmentType.BODYWEIGHT)
                    EquipmentType.BODYWEIGHT -> (exercise.equipment == EquipmentType.BODYWEIGHT)
                }
                categoryMatch && equipmentMatch && !usedIds.contains(exercise.id)
            }

            val chosen = candidates.firstOrNull() ?: ExerciseRepository.allExercises.firstOrNull {
                it.category == category && !usedIds.contains(it.id)
            } ?: ExerciseRepository.allExercises.firstOrNull { !usedIds.contains(it.id) }

            if (chosen != null) {
                usedIds.add(chosen.id)
                val initialWeight = when (chosen.equipment) {
                    EquipmentType.BODYWEIGHT -> 0.0
                    EquipmentType.DUMBBELLS -> if (profile.experience == ExperienceLevel.BEGINNER) 6.0 else 12.0
                    EquipmentType.FULL_GYM -> if (profile.experience == ExperienceLevel.BEGINNER) 20.0 else 40.0
                    EquipmentType.RESISTANCE_BANDS -> 0.0
                }

                results.add(
                    PlanExercise(
                        exerciseId = chosen.id,
                        name = chosen.name,
                        category = chosen.category,
                        targetSets = targetSets,
                        targetReps = repScheme,
                        targetWeightKg = initialWeight,
                        restSeconds = restSeconds,
                        instructionsSummary = chosen.instructions.firstOrNull() ?: "Follow proper form.",
                        alternative = chosen.alternative
                    )
                )
            }
        }
        return results
    }

    private fun buildCoachNote(profile: UserProfile): String {
        val levelAdvice = when (profile.experience) {
            ExperienceLevel.BEGINNER -> "Welcome to training! Prioritize controlled form over heavy weight. Always warm up, keep 1-2 reps in reserve, and take full rest periods."
            ExperienceLevel.INTERMEDIATE -> "Consistent progressive overload is key. Log your weights on every session and aim to increase either reps or resistance incrementally each week."
            ExperienceLevel.ADVANCED -> "Maintain high mental focus on eccentric control and peak muscle contraction. Deload every 6-8 weeks to allow joint and tendon recovery."
        }
        val goalAdvice = when (profile.goal) {
            FitnessGoal.MUSCLE_GAIN -> "Fuel your recovery with adequate protein (~1.6-2.0g per kg of bodyweight) and 7-9 hours of restful sleep."
            FitnessGoal.FAT_LOSS -> "Keep workout pace brisk, hydrate consistently, and combine your strength sessions with daily light walking (7k-10k steps)."
            FitnessGoal.STRENGTH -> "Allow full neurological rest between heavy sets (2-3 minutes) to maximize force production on every repetition."
            FitnessGoal.GENERAL_FITNESS -> "Consistency beats intensity. Even on busy days, completing 20 minutes is a win that builds lasting habit momentum."
        }
        return "$levelAdvice $goalAdvice"
    }
}
