package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutRecord(workout: WorkoutRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExerciseRecords(records: List<ExerciseRecordEntity>)

    @Query("SELECT * FROM workout_records ORDER BY dateEpochMillis DESC")
    fun getAllWorkouts(): Flow<List<WorkoutRecordEntity>>

    @Query("SELECT * FROM workout_records ORDER BY dateEpochMillis DESC LIMIT :limit")
    fun getRecentWorkouts(limit: Int): Flow<List<WorkoutRecordEntity>>

    @Query("SELECT COUNT(*) FROM workout_records")
    fun getTotalWorkoutsCount(): Flow<Int>

    @Query("SELECT * FROM exercise_records WHERE exerciseName = :name ORDER BY weightKg DESC, reps DESC LIMIT 1")
    suspend fun getPersonalBestForExercise(name: String): ExerciseRecordEntity?

    @Query("SELECT * FROM exercise_records WHERE exerciseName = :name ORDER BY dateEpochMillis DESC LIMIT :limit")
    fun getExerciseHistory(name: String, limit: Int = 10): Flow<List<ExerciseRecordEntity>>

    @Query("SELECT * FROM exercise_records ORDER BY weightKg DESC")
    fun getAllExerciseRecords(): Flow<List<ExerciseRecordEntity>>

    @Query("DELETE FROM workout_records")
    suspend fun clearAllWorkouts()

    @Query("DELETE FROM exercise_records")
    suspend fun clearAllExerciseRecords()
}

@Dao
interface WeightDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeight(weight: BodyWeightEntity): Long

    @Query("SELECT * FROM body_weight_records ORDER BY dateEpochMillis ASC")
    fun getAllWeights(): Flow<List<BodyWeightEntity>>

    @Query("SELECT * FROM body_weight_records ORDER BY dateEpochMillis DESC LIMIT 1")
    fun getLatestWeight(): Flow<BodyWeightEntity?>

    @Query("DELETE FROM body_weight_records")
    suspend fun clearAllWeights()
}
