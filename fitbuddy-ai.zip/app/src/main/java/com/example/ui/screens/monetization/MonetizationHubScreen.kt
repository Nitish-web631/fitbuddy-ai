package com.example.ui.screens.monetization

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MembershipTier
import com.example.data.model.MonetizationState
import com.example.data.model.SponsoredOffer
import com.example.ui.components.RewardedSpotlightDialog
import com.example.ui.components.SponsoredBannerCard
import com.example.ui.components.StatCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricGreen
import com.example.ui.theme.ElectricGreenBright
import com.example.ui.theme.ElectricGreenContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonetizationHubScreen(
    state: MonetizationState,
    sampleOffer: SponsoredOffer,
    onSelectTier: (MembershipTier) -> Unit,
    onToggleAds: (Boolean) -> Unit,
    onClaimReward: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var showRewardedTestDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Ad Monetization Model",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Overview Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(listOf(ElectricGreen.copy(alpha = 0.5f), DarkCardBorder))
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(ElectricGreen.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = ElectricGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "FitBuddy Revenue Engine",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF193322))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = state.tier.badge,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = ElectricGreenBright
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Hybrid Freemium & Sponsored Monetization Strategy",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = ElectricGreenBright
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "FitBuddy AI balances healthy app monetization with user retention through native sponsored partner placements, opt-in rewarded workout boosts, and an optional Pro ad-free subscription.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            // Monetization Performance Metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "Active Tier",
                    value = if (state.tier == MembershipTier.PRO_MEMBER) "PRO" else "FREE",
                    icon = Icons.Default.Star,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Rewarded Boosts",
                    value = "${state.totalPromotionsViewed}",
                    subtitle = "unlocked",
                    icon = Icons.Default.CardGiftcard,
                    iconTint = ElectricGreenBright,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Ad Status",
                    value = if (state.adsEnabled) "Active" else "Muted",
                    icon = Icons.Default.LocalOffer,
                    iconTint = if (state.adsEnabled) ElectricGreen else TextMuted,
                    modifier = Modifier.weight(1f)
                )
            }

            // Interactive Monetization Tier Switcher
            Text(
                text = "Interactive Tier Simulation",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Free Tier Card
                val isFree = (state.tier == MembershipTier.FREE_SPONSORED)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectTier(MembershipTier.FREE_SPONSORED) }
                        .testTag("tier_free_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isFree) ElectricGreenContainer else DarkSurface
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(
                            if (isFree) listOf(ElectricGreen, ElectricGreenBright)
                            else listOf(DarkCardBorder, DarkCardBorder)
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Free Tier",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isFree) ElectricGreenBright else TextPrimary
                            )
                            if (isFree) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = ElectricGreen, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(
                            text = "Ad-Supported",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• Native partner spots\n• Rewarded perk boosts\n• 100% free workout access",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Pro Tier Card
                val isPro = (state.tier == MembershipTier.PRO_MEMBER)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectTier(MembershipTier.PRO_MEMBER) }
                        .testTag("tier_pro_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPro) ElectricGreenContainer else DarkSurface
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(
                            if (isPro) listOf(ElectricGreen, ElectricGreenBright)
                            else listOf(DarkCardBorder, DarkCardBorder)
                        )
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "FitBuddy Pro",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isPro) ElectricGreenBright else TextPrimary
                            )
                            if (isPro) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = ElectricGreen, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(
                            text = "$9.99 / month",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricGreenBright,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "• Zero ads & sponsorships\n• Instant split unlocks\n• Advanced analytics",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Live Ad Placement Preview
            Text(
                text = "Live Placement Preview",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            SponsoredBannerCard(
                offer = sampleOffer,
                onOfferClick = { showRewardedTestDialog = true },
                onUpgradeClick = { onSelectTier(MembershipTier.PRO_MEMBER) }
            )

            // Test Rewarded Ad Button
            Button(
                onClick = { showRewardedTestDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("test_rewarded_ad_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1E3A28),
                    contentColor = ElectricGreenBright
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Test Rewarded 5s Sponsor Boost",
                    fontWeight = FontWeight.Bold
                )
            }

            // Production Integration & Architecture Guide Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, DarkCardBorder)))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = ElectricGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Production Ad SDK Deployment Guide",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Text(
                        text = "When exporting and publishing this app to the Google Play Store outside the restricted creator track, hook up production AdMob / AppLovin units by following this standard pipeline:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0E1310))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "1. Add AdMob dependency to build.gradle.kts:\n   implementation(\"com.google.android.gms:play-services-ads:23.x.x\")\n\n2. Add App ID to AndroidManifest.xml:\n   <meta-data android:name=\"com.google.android.gms.ads.APPLICATION_ID\"\n              android:value=\"ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy\"/>\n\n3. Initialize SDK in MainActivity onCreate:\n   MobileAds.initialize(this) { }\n\n4. Replace SponsoredBannerCard with production BannerAdView or RewardedAd load callback in MonetizationRepository.",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = ElectricGreenBright,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    if (showRewardedTestDialog) {
        RewardedSpotlightDialog(
            offer = sampleOffer,
            onRewardEarned = onClaimReward,
            onDismiss = { showRewardedTestDialog = false }
        )
    }
}
