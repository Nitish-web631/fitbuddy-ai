package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val FitBuddyDarkColorScheme = darkColorScheme(
    primary = ElectricGreen,
    onPrimary = Color(0xFF003919),
    primaryContainer = ElectricGreenContainer,
    onPrimaryContainer = ElectricGreenBright,
    secondary = ElectricGreenBright,
    onSecondary = Color(0xFF003816),
    secondaryContainer = ElectricGreenContainerBright,
    onSecondaryContainer = Color(0xFFB9F6CA),
    tertiary = AccentAmber,
    onTertiary = Color(0xFF3E2800),
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder,
    outlineVariant = Color(0xFF1B2420)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // FitBuddy AI is built with modern fitness dark theme
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = FitBuddyDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DarkBackground.toArgb()
                window.navigationBarColor = DarkBackground.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
