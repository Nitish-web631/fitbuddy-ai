package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.screens.active.ActiveWorkoutScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.ExerciseLibraryScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.progress.ProgressScreen
import com.example.ui.screens.workouts.WorkoutsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ElectricGreen
import com.example.ui.theme.ElectricGreenBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.FitBuddyViewModel

enum class FitBuddyDestination(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    WORKOUTS("workouts", "Workouts", Icons.Filled.FitnessCenter, Icons.Outlined.FitnessCenter),
    LIBRARY("library", "Library", Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
    PROGRESS("progress", "Progress", Icons.Filled.ShowChart, Icons.Outlined.ShowChart),
    PROFILE("profile", "Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

@Composable
fun FitBuddyApp(
    viewModel: FitBuddyViewModel,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val currentPlan by viewModel.currentPlan.collectAsState()
    val activeSession by viewModel.activeSession.collectAsState()
    val workouts by viewModel.allWorkouts.collectAsState()
    val personalRecords by viewModel.personalRecords.collectAsState()
    val allWeights by viewModel.allWeights.collectAsState()
    val badges by viewModel.achievementBadges.collectAsState()
    val filteredExercises by viewModel.filteredExercises.collectAsState()
    val searchQuery by viewModel.librarySearchQuery.collectAsState()
    val selectedCategory by viewModel.libraryCategory.collectAsState()
    val selectedEquipment by viewModel.libraryEquipmentFilter.collectAsState()

    val restSeconds by viewModel.restSecondsRemaining.collectAsState()
    val isRestTimerActive by viewModel.isRestTimerActive.collectAsState()
    val isRestAlarmEnabled by viewModel.isRestAlarmEnabled.collectAsState()

    val monetizationState by viewModel.monetizationState.collectAsState()
    val sponsoredOffer by viewModel.currentSponsoredOffer.collectAsState()

    var currentDestination by remember { mutableStateOf(FitBuddyDestination.HOME) }
    var inActiveWorkoutScreen by remember { mutableStateOf(false) }
    var inMonetizationHub by remember { mutableStateOf(false) }

    // If viewing Monetization Hub
    if (inMonetizationHub) {
        BackHandler { inMonetizationHub = false }
        com.example.ui.screens.monetization.MonetizationHubScreen(
            state = monetizationState,
            sampleOffer = sponsoredOffer,
            onSelectTier = { viewModel.setMembershipTier(it) },
            onToggleAds = { viewModel.setAdsEnabled(it) },
            onClaimReward = { viewModel.claimPromotionReward() },
            onBack = { inMonetizationHub = false }
        )
        return
    }

    // If activeSession is launched, automatically transition to ActiveWorkoutScreen
    if (activeSession != null && inActiveWorkoutScreen) {
        BackHandler {
            inActiveWorkoutScreen = false
        }
        ActiveWorkoutScreen(
            session = activeSession!!,
            restSecondsRemaining = restSeconds,
            isRestTimerActive = isRestTimerActive,
            isRestAlarmEnabled = isRestAlarmEnabled,
            onToggleRestAlarm = { viewModel.toggleRestAlarm(!isRestAlarmEnabled) },
            onToggleSet = { exIdx, setIdx, isDone ->
                viewModel.toggleSetCompletion(exIdx, setIdx, isDone)
            },
            onUpdateSet = { exIdx, setIdx, weight, reps ->
                viewModel.updateSetValues(exIdx, setIdx, weight, reps)
            },
            onAdd15Rest = { viewModel.addRestTime(15) },
            onAdd30Rest = { viewModel.addRestTime(30) },
            onSkipRest = { viewModel.cancelRestTimer() },
            onFinishWorkout = { notes ->
                viewModel.finishWorkout(notes) {
                    inActiveWorkoutScreen = false
                    currentDestination = FitBuddyDestination.PROGRESS
                }
            },
            onCancelWorkout = {
                viewModel.cancelActiveWorkout()
                inActiveWorkoutScreen = false
            },
            onBack = {
                inActiveWorkoutScreen = false
            }
        )
        return
    }

    // Onboarding flow if first launch
    if (!userProfile.isOnboarded) {
        OnboardingScreen(
            initialProfile = userProfile,
            onComplete = { completedProfile ->
                viewModel.completeOnboarding(completedProfile)
            }
        )
        return
    }

    // Main 5-destination app shell with M3 NavigationBar
    BackHandler(enabled = currentDestination != FitBuddyDestination.HOME) {
        currentDestination = FitBuddyDestination.HOME
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_bottom_nav"),
                containerColor = DarkSurface,
                tonalElevation = 6.dp
            ) {
                FitBuddyDestination.entries.forEach { destination ->
                    val isSelected = currentDestination == destination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                contentDescription = destination.title
                            )
                        },
                        label = {
                            Text(
                                text = destination.title,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF003816),
                            selectedTextColor = ElectricGreenBright,
                            indicatorColor = ElectricGreen,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        ),
                        modifier = Modifier.testTag("nav_tab_${destination.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                FitBuddyDestination.HOME -> {
                    HomeScreen(
                        profile = userProfile,
                        currentPlan = currentPlan,
                        workouts = workouts,
                        activeSession = activeSession,
                        monetizationState = monetizationState,
                        sponsoredOffer = sponsoredOffer,
                        onStartWorkout = { day ->
                            viewModel.startWorkout(day)
                            inActiveWorkoutScreen = true
                        },
                        onResumeActiveWorkout = {
                            inActiveWorkoutScreen = true
                        },
                        onNavigateToWorkouts = {
                            currentDestination = FitBuddyDestination.WORKOUTS
                        },
                        onOpenMonetizationHub = {
                            inMonetizationHub = true
                        }
                    )
                }

                FitBuddyDestination.WORKOUTS -> {
                    WorkoutsScreen(
                        currentPlan = currentPlan,
                        profile = userProfile,
                        onStartWorkout = { day ->
                            viewModel.startWorkout(day)
                            inActiveWorkoutScreen = true
                        },
                        onRegeneratePlan = {
                            viewModel.regeneratePlan()
                        },
                        onSelectExercise = { exId ->
                            viewModel.librarySearchQuery.value = ""
                            currentDestination = FitBuddyDestination.LIBRARY
                        }
                    )
                }

                FitBuddyDestination.LIBRARY -> {
                    ExerciseLibraryScreen(
                        exercises = filteredExercises,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.librarySearchQuery.value = it },
                        selectedCategory = selectedCategory,
                        onSelectCategory = { viewModel.libraryCategory.value = it },
                        selectedEquipment = selectedEquipment,
                        onSelectEquipment = { viewModel.libraryEquipmentFilter.value = it }
                    )
                }

                FitBuddyDestination.PROGRESS -> {
                    ProgressScreen(
                        profile = userProfile,
                        workouts = workouts,
                        personalRecords = personalRecords,
                        weights = allWeights,
                        badges = badges,
                        onLogWeight = { w, n -> viewModel.logBodyWeight(w, n) }
                    )
                }

                FitBuddyDestination.PROFILE -> {
                    ProfileScreen(
                        profile = userProfile,
                        monetizationState = monetizationState,
                        isRestAlarmEnabled = isRestAlarmEnabled,
                        onToggleRestAlarm = { viewModel.toggleRestAlarm(it) },
                        onTestAlarm = { viewModel.testAlarmAlert() },
                        onSetDeviceAlarm = { hour, minute, label ->
                            viewModel.setDeviceAlarm(hour, minute, label)
                        },
                        onSaveProfile = { updated ->
                            viewModel.updateProfile(updated)
                        },
                        onResetAllData = {
                            viewModel.resetAllUserData()
                            currentDestination = FitBuddyDestination.HOME
                        },
                        onOpenMonetizationHub = {
                            inMonetizationHub = true
                        }
                    )
                }
            }
        }
    }
}
