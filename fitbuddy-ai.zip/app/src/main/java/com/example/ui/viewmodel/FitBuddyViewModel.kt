package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.BodyWeightEntity
import com.example.data.db.WorkoutRecordEntity
import com.example.data.model.AchievementBadge
import com.example.data.model.ActiveExerciseState
import com.example.data.model.ActiveWorkoutSession
import com.example.data.model.EquipmentType
import com.example.data.model.Exercise
import com.example.data.model.LoggedSet
import com.example.data.model.MuscleCategory
import com.example.data.model.PersonalRecord
import com.example.data.model.UserProfile
import com.example.data.model.WorkoutDay
import com.example.data.model.WorkoutPlan
import com.example.data.repository.ExerciseRepository
import com.example.data.repository.FitnessHistoryRepository
import com.example.data.repository.MotivationRepository
import com.example.data.repository.UserPreferencesRepository
import com.example.data.repository.WorkoutPlannerEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FitBuddyViewModel(application: Application) : AndroidViewModel(application) {

    private val userPrefsRepo = UserPreferencesRepository(application)
    private val historyRepo = FitnessHistoryRepository(AppDatabase.getDatabase(application))
    private val monetizationRepo = com.example.data.repository.MonetizationRepository(application)

    val userProfile: StateFlow<UserProfile> = userPrefsRepo.userProfile
    val monetizationState: StateFlow<com.example.data.model.MonetizationState> = monetizationRepo.state
    val currentSponsoredOffer = MutableStateFlow(monetizationRepo.getRandomOffer())

    private val _currentPlan = MutableStateFlow(WorkoutPlannerEngine.generatePlan(userPrefsRepo.userProfile.value))
    val currentPlan: StateFlow<WorkoutPlan> = _currentPlan.asStateFlow()

    // Exercise Library Filtering
    val librarySearchQuery = MutableStateFlow("")
    val libraryCategory = MutableStateFlow(MuscleCategory.ALL)
    val libraryEquipmentFilter = MutableStateFlow<EquipmentType?>(null)

    val filteredExercises: StateFlow<List<Exercise>> = combine(
        librarySearchQuery,
        libraryCategory,
        libraryEquipmentFilter
    ) { query, cat, equip ->
        ExerciseRepository.searchExercises(query, cat, equip)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ExerciseRepository.allExercises)

    // History and Stats
    val allWorkouts: StateFlow<List<WorkoutRecordEntity>> = historyRepo.allWorkouts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalWorkoutsCount: StateFlow<Int> = historyRepo.totalWorkoutsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val personalRecords: StateFlow<List<PersonalRecord>> = historyRepo.getPersonalRecords()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWeights: StateFlow<List<BodyWeightEntity>> = historyRepo.allWeights
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestWeight: StateFlow<BodyWeightEntity?> = historyRepo.latestWeight
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val achievementBadges: StateFlow<List<AchievementBadge>> = combine(
        allWorkouts,
        userProfile,
        allWeights
    ) { workouts, profile, weights ->
        MotivationRepository.computeBadges(workouts, profile.currentStreak, weights.isNotEmpty())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Workout Session
    private val _activeSession = MutableStateFlow<ActiveWorkoutSession?>(null)
    val activeSession: StateFlow<ActiveWorkoutSession?> = _activeSession.asStateFlow()

    // Rest Timer
    private val _restSecondsRemaining = MutableStateFlow(0)
    val restSecondsRemaining: StateFlow<Int> = _restSecondsRemaining.asStateFlow()

    private val _isRestTimerActive = MutableStateFlow(false)
    val isRestTimerActive: StateFlow<Boolean> = _isRestTimerActive.asStateFlow()

    private var restTimerJob: Job? = null
    private var workoutTickerJob: Job? = null

    init {
        // Observe profile changes to auto-update generated plan
        viewModelScope.launch {
            userProfile.collect { profile ->
                _currentPlan.value = WorkoutPlannerEngine.generatePlan(profile)
            }
        }
    }

    fun completeOnboarding(profile: UserProfile) {
        val updated = profile.copy(isOnboarded = true)
        userPrefsRepo.saveProfile(updated)
        _currentPlan.value = WorkoutPlannerEngine.generatePlan(updated)
    }

    fun updateProfile(profile: UserProfile) {
        userPrefsRepo.saveProfile(profile)
        _currentPlan.value = WorkoutPlannerEngine.generatePlan(profile)
    }

    fun regeneratePlan() {
        _currentPlan.value = WorkoutPlannerEngine.generatePlan(userProfile.value)
    }

    // --- Active Workout Control ---

    fun startWorkout(day: WorkoutDay) {
        val activeExercises = day.exercises.map { planEx ->
            val setList = (1..planEx.targetSets).map { setNum ->
                val targetRepsNum = planEx.targetReps.filter { it.isDigit() }.take(2).toIntOrNull() ?: 10
                LoggedSet(
                    setNumber = setNum,
                    weightKg = planEx.targetWeightKg,
                    reps = targetRepsNum,
                    isCompleted = false
                )
            }
            ActiveExerciseState(
                exerciseId = planEx.exerciseId,
                name = planEx.name,
                category = planEx.category,
                restSeconds = planEx.restSeconds,
                alternative = planEx.alternative,
                sets = setList
            )
        }

        _activeSession.value = ActiveWorkoutSession(
            planTitle = currentPlan.value.splitType,
            dayTitle = day.title,
            dayNumber = day.dayNumber,
            elapsedSeconds = 0,
            exercises = activeExercises,
            isFinished = false
        )

        startWorkoutTicker()
    }

    private fun startWorkoutTicker() {
        workoutTickerJob?.cancel()
        workoutTickerJob = viewModelScope.launch {
            while (_activeSession.value != null && !_activeSession.value!!.isFinished) {
                delay(1000)
                _activeSession.value = _activeSession.value?.let { current ->
                    current.copy(elapsedSeconds = current.elapsedSeconds + 1)
                }
            }
        }
    }

    fun toggleSetCompletion(exerciseIndex: Int, setIndex: Int, isCompleted: Boolean) {
        val session = _activeSession.value ?: return
        if (exerciseIndex !in session.exercises.indices) return
        val exercise = session.exercises[exerciseIndex]
        if (setIndex !in exercise.sets.indices) return

        val updatedSets = exercise.sets.mapIndexed { idx, item ->
            if (idx == setIndex) item.copy(isCompleted = isCompleted) else item
        }
        val updatedExercises = session.exercises.mapIndexed { idx, item ->
            if (idx == exerciseIndex) item.copy(sets = updatedSets) else item
        }
        _activeSession.value = session.copy(exercises = updatedExercises)

        if (isCompleted) {
            startRestTimer(exercise.restSeconds)
        }
    }

    fun updateSetValues(exerciseIndex: Int, setIndex: Int, weightKg: Double, reps: Int) {
        val session = _activeSession.value ?: return
        if (exerciseIndex !in session.exercises.indices) return
        val exercise = session.exercises[exerciseIndex]
        if (setIndex !in exercise.sets.indices) return

        val updatedSets = exercise.sets.mapIndexed { idx, item ->
            if (idx == setIndex) item.copy(weightKg = weightKg.coerceAtLeast(0.0), reps = reps.coerceAtLeast(1)) else item
        }
        val updatedExercises = session.exercises.mapIndexed { idx, item ->
            if (idx == exerciseIndex) item.copy(sets = updatedSets) else item
        }
        _activeSession.value = session.copy(exercises = updatedExercises)
    }

    fun finishWorkout(notes: String = "", onFinished: (Long) -> Unit = {}) {
        val session = _activeSession.value ?: return
        workoutTickerJob?.cancel()
        cancelRestTimer()

        viewModelScope.launch {
            val recordId = historyRepo.saveCompletedWorkout(session, notes)
            userPrefsRepo.recordWorkoutCompletion()
            _activeSession.value = null
            onFinished(recordId)
        }
    }

    fun cancelActiveWorkout() {
        workoutTickerJob?.cancel()
        cancelRestTimer()
        _activeSession.value = null
    }

    // --- Rest Timer Control ---

    // Rest Alarm Settings
    val isRestAlarmEnabled = MutableStateFlow(true)

    fun toggleRestAlarm(enabled: Boolean) {
        isRestAlarmEnabled.value = enabled
    }

    fun startRestTimer(seconds: Int) {
        restTimerJob?.cancel()
        _restSecondsRemaining.value = seconds.coerceAtLeast(5)
        _isRestTimerActive.value = true

        restTimerJob = viewModelScope.launch {
            val context = getApplication<Application>()
            while (_restSecondsRemaining.value > 0) {
                delay(1000)
                _restSecondsRemaining.value = _restSecondsRemaining.value - 1
                if (isRestAlarmEnabled.value && _restSecondsRemaining.value in 1..3) {
                    com.example.util.AlarmAlertManager.playCountdownPip(context)
                }
            }
            _isRestTimerActive.value = false
            if (isRestAlarmEnabled.value) {
                com.example.util.AlarmAlertManager.playWorkoutAlarm(context)
            } else {
                com.example.util.AlarmAlertManager.triggerAlarmVibration(context)
            }
        }
    }

    fun addRestTime(seconds: Int) {
        _restSecondsRemaining.value = (_restSecondsRemaining.value + seconds).coerceIn(0, 300)
        if (!_isRestTimerActive.value && _restSecondsRemaining.value > 0) {
            startRestTimer(_restSecondsRemaining.value)
        }
    }

    fun cancelRestTimer() {
        restTimerJob?.cancel()
        _isRestTimerActive.value = false
        _restSecondsRemaining.value = 0
    }

    fun testAlarmAlert() {
        val context = getApplication<Application>()
        com.example.util.AlarmAlertManager.playWorkoutAlarm(context)
    }

    fun setDeviceAlarm(hour: Int, minute: Int, label: String = "FitBuddy Workout"): Boolean {
        val context = getApplication<Application>()
        return com.example.util.AlarmAlertManager.setSystemAlarm(context, hour, minute, label)
    }

    // --- Weight Logging ---

    fun logBodyWeight(weightKg: Double, note: String = "") {
        viewModelScope.launch {
            historyRepo.logBodyWeight(weightKg, note)
        }
    }

    // --- Reset All Data ---
    fun resetAllUserData() {
        viewModelScope.launch {
            cancelActiveWorkout()
            userPrefsRepo.resetAllData()
            historyRepo.clearAllHistory()
            _currentPlan.value = WorkoutPlannerEngine.generatePlan(UserProfile())
        }
    }

    // --- Monetization & Ad Model ---
    fun setMembershipTier(tier: com.example.data.model.MembershipTier) {
        monetizationRepo.setMembershipTier(tier)
    }

    fun setAdsEnabled(enabled: Boolean) {
        monetizationRepo.setAdsEnabled(enabled)
    }

    fun claimPromotionReward() {
        monetizationRepo.recordPromotionRewardClaimed()
    }

    fun refreshSponsoredOffer() {
        currentSponsoredOffer.value = monetizationRepo.getRandomOffer()
    }
}
