package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.BodyWeightEntity
import com.example.data.db.WorkoutRecordEntity
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.ElectricGreen
import com.example.ui.theme.ElectricGreenBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun WeeklyActivityTracker(
    workouts: List<WorkoutRecordEntity>,
    modifier: Modifier = Modifier
) {
    val today = LocalDate.now()
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val weekDays = (0..6).map { monday.plusDays(it.toLong()) }

    val workoutDays = workouts.map {
        Instant.ofEpochMilli(it.dateEpochMillis)
            .atZone(ZoneId.systemDefault())
            .toLocalDate()
    }.toSet()

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, Color(0xFF1B241E))))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Weekly Activity",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                val completedCountThisWeek = weekDays.count { workoutDays.contains(it) }
                Text(
                    text = "$completedCountThisWeek / 7 days",
                    style = MaterialTheme.typography.labelMedium,
                    color = ElectricGreenBright,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                weekDays.forEach { date ->
                    val isDone = workoutDays.contains(date)
                    val isToday = date.isEqual(today)
                    val dayLetter = date.dayOfWeek.getDisplayName(TextStyle.NARROW, Locale.getDefault())

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = dayLetter,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isToday) ElectricGreen else TextMuted,
                            fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium
                        )

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isDone -> ElectricGreen
                                        isToday -> Color(0xFF1A3324)
                                        else -> Color(0xFF161E1A)
                                    }
                                )
                                .then(
                                    if (isToday && !isDone) {
                                        Modifier.border(1.dp, ElectricGreen, CircleShape)
                                    } else Modifier
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isDone) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Workout completed",
                                    tint = Color(0xFF003816),
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                Text(
                                    text = "${date.dayOfMonth}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 11.sp,
                                    color = if (isToday) ElectricGreen else TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeightProgressChart(
    weights: List<BodyWeightEntity>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(DarkCardBorder, Color(0xFF1B241E))))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Body Weight Trend",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = if (weights.isNotEmpty()) "Latest: ${weights.last().weightKg} kg" else "No weights logged yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(ElectricGreen.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = null,
                        tint = ElectricGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (weights.size < 2) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF111814)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (weights.isEmpty()) "Log your weight to see your progress chart" else "Log at least 2 entries to see the trend line",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            } else {
                val minWeight = weights.minOf { it.weightKg } - 1.0
                val maxWeight = (weights.maxOf { it.weightKg } + 1.0).coerceAtLeast(minWeight + 2.0)
                val weightRange = maxWeight - minWeight

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    val width = size.width
                    val height = size.height
                    val stepX = width / (weights.size - 1)

                    val points = weights.mapIndexed { index, item ->
                        val x = index * stepX
                        val normalizedY = ((item.weightKg - minWeight) / weightRange).toFloat()
                        val y = height - (normalizedY * height * 0.8f) - (height * 0.1f)
                        Offset(x, y)
                    }

                    // Draw baseline grid lines
                    drawLine(
                        color = Color(0xFF202A24),
                        start = Offset(0f, height * 0.2f),
                        end = Offset(width, height * 0.2f),
                        strokeWidth = 1f
                    )
                    drawLine(
                        color = Color(0xFF202A24),
                        start = Offset(0f, height * 0.8f),
                        end = Offset(width, height * 0.8f),
                        strokeWidth = 1f
                    )

                    // Draw gradient fill area under line
                    val fillPath = Path().apply {
                        moveTo(0f, height)
                        lineTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                        lineTo(points.last().x, height)
                        close()
                    }

                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                ElectricGreen.copy(alpha = 0.25f),
                                Color.Transparent
                            ),
                            startY = 0f,
                            endY = height
                        )
                    )

                    // Draw line
                    val strokePath = Path().apply {
                        moveTo(points.first().x, points.first().y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }

                    drawPath(
                        path = strokePath,
                        color = ElectricGreen,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw dots on data points
                    points.forEach { point ->
                        drawCircle(
                            color = Color(0xFF0A0E0C),
                            radius = 5.dp.toPx(),
                            center = point
                        )
                        drawCircle(
                            color = ElectricGreenBright,
                            radius = 3.5.dp.toPx(),
                            center = point
                        )
                    }
                }
            }
        }
    }
}
