package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Electric Green & Deep Dark Palette for FitBuddy AI
val ElectricGreen = Color(0xFF00E676)
val ElectricGreenBright = Color(0xFF69F0AE)
val ElectricGreenDark = Color(0xFF00B0FF)
val ElectricGreenContainer = Color(0xFF0D331E)
val ElectricGreenContainerBright = Color(0xFF144D2D)

val DarkBackground = Color(0xFF0A0E0C)
val DarkSurface = Color(0xFF121714)
val DarkSurfaceVariant = Color(0xFF1B231F)
val DarkCardBorder = Color(0xFF26332C)

val AccentAmber = Color(0xFFFFB300)
val AccentRed = Color(0xFFFF5252)
val AccentBlue = Color(0xFF40C4FF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0BEC5)
val TextMuted = Color(0xFF6E8077)

val DarkGrayChip = Color(0xFF1F2823)
